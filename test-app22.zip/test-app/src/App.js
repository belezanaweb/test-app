import React from 'react';
import Routes from './routes';

const App: () => React$Node = () => <Routes />;

export default App;
