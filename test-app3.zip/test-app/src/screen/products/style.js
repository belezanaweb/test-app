import styled from 'styled-components/native';

export const Teste = styled.Text`
	font-size: 50px;
`;
