import modalConfirmPurchase from './modalConfirmPurchase';
import modalFormRemember from './modalFormRememberMe';

export default {
	modalConfirmPurchase,
	modalFormRemember,
};
